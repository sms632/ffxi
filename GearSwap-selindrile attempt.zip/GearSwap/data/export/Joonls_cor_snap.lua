sets.exported={
    main="Naegling",
    sub="Tauret",
    range={ name="Anarchy +2", augments={'Delay:+60','TP Bonus +1000',}},
    ammo="Eminent Bullet",
    head={ name="Taeon Chapeau", augments={'Accuracy+11','"Dual Wield"+5','"Snapshot"+4',}},
    body={ name="Pursuer's Doublet", augments={'HP+50','Crit. hit rate+4%','"Snapshot"+6',}},
    hands={ name="Lanun Gants", augments={'Enhances "Fold" effect',}},
    legs="Nahtirah Trousers",
    feet={ name="Taeon Boots", augments={'Attack+15','"Dual Wield"+5','Sklchn.dmg.+3%',}},
    back="Camulus's Mantle",
}