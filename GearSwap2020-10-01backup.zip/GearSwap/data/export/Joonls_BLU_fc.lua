sets.exported={
    main="Kaja Sword",
    sub={ name="Nibiru Blade", augments={'DEX+10','Accuracy+20','Mag. Acc.+15',}},
    ammo="Sapience Orb",
    legs={ name="Psycloth Lappas", augments={'MP+80','Mag. Acc.+15','"Fast Cast"+7',}},
    feet="Jhakri Pigaches +2",
    waist="Witful Belt",
    right_ear="Loquac. Earring",
    left_ring="Weather. Ring",
    right_ring="Jhakri Ring",
}