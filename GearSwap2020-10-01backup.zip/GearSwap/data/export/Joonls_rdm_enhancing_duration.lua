sets.exported={
    main={ name="Grioavolr", augments={'Enh. Mag. eff. dur. +9','CHR+13','Mag. Acc.+28','"Mag.Atk.Bns."+14',}},
    head={ name="Telchine Cap", augments={'Mag. Evasion+12','"Conserve MP"+1','Enh. Mag. eff. dur. +7',}},
    body={ name="Telchine Chas.", augments={'Mag. Evasion+4','"Cure" spellcasting time -6%','Enh. Mag. eff. dur. +8',}},
    hands="Atrophy Gloves +1",
    legs={ name="Telchine Braconi", augments={'"Mag.Atk.Bns."+10','"Regen"+2','Enh. Mag. eff. dur. +9',}},
    feet={ name="Telchine Pigaches", augments={'Evasion+2','Enmity-4','Enh. Mag. eff. dur. +10',}},
    back={ name="Sucellos's Cape", augments={'INT+20','Mag. Acc+20 /Mag. Dmg.+20','Mag. Acc.+6','"Mag.Atk.Bns."+5','Damage taken-5%',}},
}