sets.exported={
    main="Kaja Knife",
    sub={ name="Taming Sari", augments={'STR+10','DEX+10','DMG:+15','"Treasure Hunter"+1',}},
    ammo="Charis Feather",
    body="Turms Harness",
    hands="Maxixi Bangles +2",
    legs="Mummu Kecks +1",
    feet="Tandava Crackows",
    neck="Bathy Choker",
    waist="Fotia Belt",
    left_ring="Sheltered Ring",
    right_ring={ name="Dark Ring", augments={'Enemy crit. hit rate -2','Magic dmg. taken -4%','Phys. dmg. taken -6%',}},
    back="Solemnity Cape",
}