sets.exported={
    main="Kaja Sword",
    sub={ name="Nibiru Blade", augments={'DEX+10','Accuracy+20','Mag. Acc.+15',}},
    legs={ name="Herculean Trousers", augments={'Enmity+1','"Blood Pact" ability delay -2','"Treasure Hunter"+1',}},
    waist="Chaac Belt",
}