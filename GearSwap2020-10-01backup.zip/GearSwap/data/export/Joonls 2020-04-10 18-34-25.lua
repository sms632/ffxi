sets.exported={
    body={ name="Viti. Tabard +1", augments={'Enhances "Chainspell" effect',}},
    hands="Atrophy Gloves +1",
    legs={ name="Carmine Cuisses +1", augments={'Accuracy+20','Attack+12','"Dual Wield"+6',}},
    feet="Leth. Houseaux",
    neck="Incanter's Torque",
    back={ name="Sucellos's Cape", augments={'INT+20','Mag. Acc+20 /Mag. Dmg.+20','Mag. Acc.+6','"Mag.Atk.Bns."+10','Damage taken-5%',}},
}