sets.exported={
    main="Kaja Knife",
    sub={ name="Taming Sari", augments={'STR+10','DEX+10','DMG:+15','"Treasure Hunter"+1',}},
    head="Malignance Chapeau",
    body="Meg. Cuirie +2",
    hands="Malignance Gloves",
    legs="Mummu Kecks +1",
    feet={ name="Herculean Boots", augments={'Accuracy+7','Phys. dmg. taken -3%','"Refresh"+1','Mag. Acc.+19 "Mag.Atk.Bns."+19',}},
    neck="Twilight Torque",
    left_ring={ name="Dark Ring", augments={'Phys. dmg. taken -5%','Magic dmg. taken -3%',}},
    right_ring={ name="Dark Ring", augments={'Enemy crit. hit rate -2','Magic dmg. taken -4%','Phys. dmg. taken -6%',}},
    back="Solemnity Cape",
}