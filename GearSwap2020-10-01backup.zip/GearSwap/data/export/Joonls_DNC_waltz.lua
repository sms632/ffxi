sets.exported={
    main="Kaja Knife",
    sub={ name="Taming Sari", augments={'STR+10','DEX+10','DMG:+15','"Treasure Hunter"+1',}},
    head="Mummu Bonnet +1",
    body="Maxixi Casaque +1",
    feet="Maxixi Shoes +1",
    left_ear="Handler's Earring +1",
    right_ear="Handler's Earring",
    left_ring={ name="Dark Ring", augments={'Phys. dmg. taken -5%','Magic dmg. taken -3%',}},
    right_ring={ name="Dark Ring", augments={'Enemy crit. hit rate -2','Magic dmg. taken -4%','Phys. dmg. taken -6%',}},
    back={ name="Toetapper Mantle", augments={'"Store TP"+4','"Dual Wield"+4','Weapon skill damage +1%',}},
}