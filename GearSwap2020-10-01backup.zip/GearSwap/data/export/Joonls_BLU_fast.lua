sets.exported={
    ammo="Sapience Orb",
    head={ name="Psycloth Tiara", augments={'Mag. Acc.+20','"Fast Cast"+10','INT+7',}},
    body={ name="Taeon Tabard", augments={'Accuracy+9','"Triple Atk."+1','"Snapshot"+4',}},
    hands="Jhakri Cuffs +2",
    legs={ name="Psycloth Lappas", augments={'MP+80','Mag. Acc.+15','"Fast Cast"+7',}},
    feet="Jhakri Pigaches +2",
    waist="Witful Belt",
    left_ear="Loquac. Earring",
    left_ring="Weather. Ring",
    right_ring="Prolix Ring",
}