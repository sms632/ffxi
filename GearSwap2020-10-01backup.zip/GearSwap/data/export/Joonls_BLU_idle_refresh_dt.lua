sets.exported={
    main="Naegling",
    sub={ name="Nibiru Cudgel", augments={'MP+50','INT+10','"Mag.Atk.Bns."+15',}},
    head="Malignance Chapeau",
    body="Jhakri Robe +2",
    hands="Malignance Gloves",
    legs="Aya. Cosciales +1",
    feet={ name="Herculean Boots", augments={'Accuracy+7','Phys. dmg. taken -3%','"Refresh"+1','Mag. Acc.+19 "Mag.Atk.Bns."+19',}},
    waist="Fucho-no-Obi",
    left_ring="Defending Ring",
    right_ring={ name="Dark Ring", augments={'Enemy crit. hit rate -2','Magic dmg. taken -4%','Phys. dmg. taken -6%',}},
    back="Solemnity Cape",
}