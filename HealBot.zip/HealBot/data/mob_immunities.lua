return {
    ['Bedrock Crag'] = S{
        4,
        194
    },
    ['Bozzetto Necronura'] = S{
        7
    },
    ['Broadleaf Palm'] = S{
        2,
        194
    },
    ['Cloud of Darkness'] = S{
        7
    },
    ['Despot'] = S{
        194
    },
    ['Dhorme Khimaira'] = S{
        13
    },
    ['Dimensional Tether'] = S{
        194
    },
    ['Gnarled Rampart'] = S{
        194
    },
    ['Knotted Root'] = S{
        194
    },
    ['Sere Stump'] = S{
        194
    },
    ['Wintry Cave'] = S{
        5,
        13
    },
    ['_comment'] = 'This file is automatically updated with buff IDs as immunities are discovered'
}
